int main() {
    p();
    printInt(1);
    return 0;
}

void p() {}
