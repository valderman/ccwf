// multiple variables of the same type declared 
// and possibly initialized in the same statement

int main() {
 int x, y = 7;
 x = -1234234;
 printInt(x);
 printInt(y);
 return 0 ;

}