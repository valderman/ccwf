int main() {
    // Arithmetic operations
    int x;
    x++;
    printInt(x);
    x--;
    printInt(x);
    x--;
    printInt(x);
    printInt(x+x);

    return 0;
}
