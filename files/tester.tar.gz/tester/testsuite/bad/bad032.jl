int main() { 
    boolean b=false;
    if(b);
    else return 0;
}
