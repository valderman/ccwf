int main() { 
   int while;
   return 1;
}
