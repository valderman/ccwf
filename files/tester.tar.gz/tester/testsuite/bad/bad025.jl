int main() {
   return f(3); 
}

int f(int x) {
    if (x<0) 
       return x;
}
