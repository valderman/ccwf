
typedef struct WrongSpelled *Dab;

struct SpelledWrong {
  int x;
}


int main() {
  return 0;
}

