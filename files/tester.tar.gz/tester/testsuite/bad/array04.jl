

int main() {
  int b = 3;
  int c = b.length;
  return 0;
}
