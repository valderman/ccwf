int main() { 
    if(true);
    else return 0;
}
