// passing integers to printDouble().

int main() {
	printDouble(1);
	return 0 ;
}
