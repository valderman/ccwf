int main() { 
    boolean b=false;
    while(b) return 0; 
}
