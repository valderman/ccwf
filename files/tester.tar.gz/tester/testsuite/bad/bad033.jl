int main() { 
    boolean b=false;
    if(b) return 0;
}
