{-# LANGUAGE GeneralizedNewtypeDeriving, TemplateHaskell, DeriveDataTypeable #-}

module State where

import Control.Lens hiding (Const)
import Control.Monad.State
import qualified Data.Map as M
import Data.Data
import qualified Data.Generics.Uniplate.Data as U
import Data.Typeable


-- Tiny language AST

type Ident = String

data AST 
  = Const Int          -- integer literals
  | Var Ident          -- variables
  | Plus AST AST       -- addition
  | Sub  AST AST       -- subtraction
  | Neg  AST           -- negation
  | Let Ident AST AST  -- bind Ident to first AST and is in scope in second AST
  deriving (Show, Eq, Typeable, Data)

ex1, ex2, ex2res, ex3, ex3res, ex4 :: AST
ex1    = Sub (Const 1) (Const 2)
ex2    = Let "a" (Const 2) (Plus (Var "a") (Var "a"))
ex2res = Let "v0" (Const 2) (Plus (Var "v0") (Var "v0"))
ex3    = Var "apa"
ex3res = Var "apa"
ex4    = Let "a" (Const 1) (Let "b" (Const 2) (Plus (Var "a") (Var "b")))
ex5    = Let "a" (Const 1) (Let "a" (Const 2) (Sub  (Var "a") (Var "a")))

instance Num AST where
    (+) = Plus
    (-) = Sub
    negate = Neg
    fromInteger = Const . fromInteger
    (*) = undefined
    abs = undefined
    signum = undefined

-- Task description:
--   * return all constants in the expression
--   * rename all local variables to fresh names

-- The CF Monad

data CFState = CFState 
  { _consts  :: [Int] 
  , _subst   :: M.Map Ident Ident
  , _newName :: Int
  }

makeLenses ''CFState

initState :: CFState
initState = CFState [] M.empty 0

type CF a = StateT CFState (Either String) a

addConstant :: Int -> CF ()
addConstant i = 
    consts %= (\is -> i:is)

lookupVar :: Ident -> CF Ident
lookupVar v = do 
    uses subst (M.lookup v) >>= maybe (return v) return 

freshName :: CF Ident
freshName = do 
    fmap ('v':) $ newName %%= (\x -> (show x, x+1))

substituteIn :: Ident -> Ident -> CF a -> CF a
substituteIn v w action = do 
    s   <- subst %%= \s -> (s, M.insert v w s)
    res <- action
    subst .= s
    return res

-- Implementation

getConstFresh :: AST -> Either String (AST, [Int])
getConstFresh ast = do 
    (ast', st) <- runStateT (rec ast) initState
    return (ast', st^.consts)
  where
    rec a = case a of
        Const i   -> do 
            addConstant i
            return a
        Var v     -> liftM Var (lookupVar v)
        Plus x y  -> liftM2 Plus (rec x) (rec y)
        Sub x y   -> liftM2 Sub (rec x) (rec y)
        Neg x     -> liftM Neg (rec x)
        Let v x y -> do
            x' <- rec x
            v' <- freshName
            y' <- substituteIn v v' (rec y)
            return (Let v' x' y')

getConsts :: AST -> [Int]
getConsts ast = [n | Const n <- U.universe ast]

refresh :: AST -> Either String AST
refresh = flip evalStateT initState . rec
  where
    rec ast = case ast of
        Var v     -> liftM Var (lookupVar v)
        Let v x y -> do
            x' <- rec x
            v' <- freshName
            y' <- substituteIn v v' (rec y)
            return (Let v' x' y')
        _ -> U.descendM rec ast
