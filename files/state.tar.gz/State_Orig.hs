{-# LANGUAGE GeneralizedNewtypeDeriving #-}

module State where

import Control.Monad.State
import qualified Data.Map as M
import Data.Typeable


-- Tiny language AST

type Ident = String

data AST 
  = Const Int          -- integer literals
  | Var Ident          -- variables
  | Plus AST AST       -- addition
  | Sub  AST AST       -- subtraction
  | Neg  AST           -- negation
  | Let Ident AST AST  -- bind Ident to first AST and is in scope in second AST
  deriving (Show, Eq, Typeable)

ex1, ex2, ex2res, ex3, ex3res, ex4 :: AST
ex1    = Sub (Const 1) (Const 2)
ex2    = Let "a" (Const 2) (Plus (Var "a") (Var "a"))
ex2res = Let "v0" (Const 2) (Plus (Var "v0") (Var "v0"))
ex3    = Var "apa"
ex3res = Var "apa"
ex4    = Let "a" (Const 1) (Let "b" (Const 2) (Plus (Var "a") (Var "b")))
ex5    = Let "a" (Const 1) (Let "a" (Const 2) (Sub  (Var "a") (Var "a")))

-- Task description:
--   * return all constants in the expression
--   * rename all local variables to fresh names

-- The CF Monad

data CFState = CFState 
  { consts  :: [Int] 
  , subst   :: M.Map Ident Ident
  , newName :: Int
  }

initState :: CFState
initState = CFState [] M.empty 0

type CF a = StateT CFState (Either String) a

addConstant :: Int -> CF ()
addConstant i = do 
    st <- get
    put (st { consts = i : consts st})

lookupVar :: Ident -> CF Ident
lookupVar v = do 
    st <- get
    case M.lookup v (subst st) of
        Nothing -> return v
        Just v' -> return v'

freshName :: CF Ident
freshName = do 
    st <- get
    let n = newName st
    put (st { newName = n + 1 })
    return ('v' : show n)

substituteIn :: Ident -> Ident -> CF a -> CF a
substituteIn v w action = do 
    st <- get
    let s = subst st
    put (st { subst = M.insert v w s})
    res <- action
    st' <- get
    put (st { subst = s })
    return res

-- Implementation

getConstFresh :: AST -> Either String (AST, [Int])
getConstFresh ast = do 
    (ast', st) <- runStateT (rec ast) initState
    return (ast', consts st)
  where
    rec a = case a of
        Const i -> do 
            addConstant i
            return a
        Var v -> do 
            v' <- lookupVar v
            return (Var v')
        Plus x y -> do 
            x' <- rec x
            y' <- rec y
            return (Plus x' y')
        Sub x y -> do 
            x' <- rec x
            y' <- rec y
            return (Sub x' y')
        Neg x -> do
            x' <- rec x
            return (Neg x')
        Let v x y -> do
            x' <- rec x
            v' <- freshName
            y' <- substituteIn v v' (rec y)
            return (Let v' x' y')
